import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

class Deck {

    private static final int MAX_NUM_CARDS = 52;

    private ArrayList<Card> cards;

    Deck() {
        this.cards = new ArrayList<>();
        this.populateDeck();
    }

    /**
     * Performs a primitive shuffling of the deck. We iterate
     * through the deck of cards, taking the ith card and swapping
     * it with another random card in the deck.
     */
    public void shuffleDeck() {
        final Random r = new Random();
        for (int i = 0; i < this.cards.size(); i++) {
            Card tmp = this.cards.get(i);
            int ridx = r.nextInt(this.cards.size());
            Card rand = this.cards.get(ridx);
            this.cards.set(ridx, tmp);
            this.cards.set(i, rand);
        }
    }

    /**
     * Retrieves a card from the "top" of the deck.
     *
     * @return card on top of the deck.
     */
    public Card drawCard() {
        if (!this.isEmpty()) {
            return this.cards.remove(this.cards.size() - 1);
        } else {
            return null;
        }
    }

    public boolean isEmpty() {
        return this.cards.isEmpty();
    }

    @Override
    public String toString() {
        return this.cards.toString();
    }

    /**
     * Instantiates the deck to contain all 52 cards.
     */
    private void populateDeck() {
        // For every suit, create 13 cards, the last four of which all have
        // a value of four.
        Iterator<Suit> it = Suit.iterator();
        while (it.hasNext()) {
            Suit s = it.next();
            for (int i = 1; i <= MAX_NUM_CARDS / Suit.NUM_SUITS; i++) {
                this.cards.add(new Card(s, Math.min(10, i)));
            }
        }
    }
}
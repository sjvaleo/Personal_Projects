import java.util.ArrayList;
import java.util.Random;

class AI {

    private ArrayList<Card> hand;

    AI() {
        this.hand = new ArrayList<>();
    }

    public void addCard(Card c) {
        this.hand.add(c);
    }

    public void clearHand() {
        this.hand.clear();
    }

    public boolean play(Deck d) {
        int score = getScore();
        if (score < 16) {
            hand.add(d.drawCard());
            return true;
        } else if (score > 16 && score < 21) {
            Random random = new Random();
            int k = random.nextInt(4);
            if (k == 0) {
                hand.add(d.drawCard());
                return true;
            }
        }
        return false;
    }

    public int getScore() {
        return hand.stream().map(Card::getValue).reduce(0, Integer::sum);
    }
}
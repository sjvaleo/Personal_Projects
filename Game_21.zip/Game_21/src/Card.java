class Card {

    private Suit suit;
    private int value;

    Card(Suit suit, int value) {
        this.suit = suit; this.value = value;
    }

    @Override
    public String toString() {

        return String.format("%d of %s", value, suit);
    }

    public int getValue() {
        return this.value;
    }
}
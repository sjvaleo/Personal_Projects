import java.util.ArrayList;

class Player {

    private ArrayList<Card> hand;

    Player() {
        this.hand = new ArrayList<>();
    }

    public void addCard(Card c) {
        this.hand.add(c);
    }

    public void clearHand() {
        this.hand.clear();
    }

    public int getScore() {
        return this.hand.stream().map(Card::getValue).reduce(0, Integer::sum);
    }

    @Override
    public String toString() {
        return String.format("Score: %d\nHand: %s\n", this.getScore(), this.hand.toString());
    }
}
import java.util.Scanner;

class Game {

    private final int MAX_SCORE = 21;
    private Player player;
    private AI ai;


    Game() {
        this.player = new Player();
        this.ai = new AI();
    }

    /**
     * Plays a game of "21 or BlackJack", where the player has to draw cards until they
     * get as close to 21 as possible without going over. The dealer/ AI will also be playing.
     * You will try to beat it!
     */

    public void playGame() {
        Scanner in = new Scanner(System.in);
        boolean continuePlaying = true;
        while (continuePlaying) {
            this.player.clearHand();
            this.ai.clearHand();



            Deck d = new Deck();
            d.shuffleDeck();

            this.player.addCard(d.drawCard());
            this.player.addCard(d.drawCard());
            this.ai.addCard(d.drawCard());
            this.ai.addCard(d.drawCard());



            while (this.player.getScore() <= this.MAX_SCORE) {
                System.out.println(this.player);
                System.out.println("Do you want to draw? (yes/no)");
                String resp = in.nextLine();
                if (resp.equals("yes")) {
                    this.player.addCard(d.drawCard());
                } else {
                    break;
                }
            }

            while (this.ai.play(d)) {
            }

            System.out.println(this.player);
            System.out.println("AI's score: " + this.ai.getScore());

            int playerScore = this.player.getScore();
            int aiScore = this.ai.getScore();




            if (playerScore > this.MAX_SCORE) {
                System.out.println("You lose!");
            } else if (aiScore > this.MAX_SCORE) {
                System.out.println("AI loses! You win!");
            } else if (playerScore > aiScore) {
                System.out.println("You win!");
            } else if (aiScore > playerScore) {
                System.out.println("AI wins!");
            } else {
                System.out.println("It's a tie!");
            }
            System.out.println("Do you want to continue playing?");
            String resp = in.nextLine();
            continuePlaying = resp.equals("yes");
        }
    }

    public static void main(String[] args) {
        new Game().playGame();
    }
}